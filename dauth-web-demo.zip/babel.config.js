module.exports = {
  presets: [
    '@vue/cli-plugin-babel/preset'
  ],
  compact: false,
}
